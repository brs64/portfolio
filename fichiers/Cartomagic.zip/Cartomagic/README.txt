Pour jouer au jeu il suffit de lancer le fichier Cartomagic.exe
